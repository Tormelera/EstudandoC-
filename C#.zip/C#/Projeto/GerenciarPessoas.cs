﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public class GerenciarPessoas
    {
        
        private List<Pessoa> ListaPessoa = new List<Pessoa>();
        
        public void CadastrarPessoa(Pessoa pessoa)
        {
            

            

            ListaPessoa.Add(pessoa);

        }

        public Pessoa LerPessoa(Pessoa p)
        {
            Console.WriteLine("Digite o nome.");
            p.nomeP = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite a idade.");
            p.idade = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite o CPF.");
            p.cpf = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite o e-mail.");
            p.email = Console.ReadLine();
            Console.WriteLine();

            return p;
        }

        public void ListarPessoa()
        {
            foreach (Pessoa Atual in ListaPessoa)
            {
                ImprimePessoa(Atual);
            }

        }

        public void ImprimePessoa(Pessoa pessoa)
        {
            Console.WriteLine($"\nNome:{pessoa.nomeP}\n\nIdade:{pessoa.idade}\n\nCPF:{pessoa.cpf}\n\nE-mail:{pessoa.email}.\n\n---------------------------\n");
        }

        public Pessoa BuscarPessoa(string nome)
        {

            foreach (Pessoa Atual in ListaPessoa)
            {
                if (nome.ToLower().Equals(Atual.nomeP.ToLower()))
                {
                    ImprimePessoa(Atual);
                    return Atual;
                    
                }
                
            }


            return null;
            
        }

        public void EditarPessoa(Pessoa p, string num)
        {

            
                switch (num)
                {
                    case "1":

                        Console.WriteLine("Insira o novo nome para esse cadastro.");
                        p.nomeP = Console.ReadLine();
                        Console.WriteLine($"Você editou o nome desse cadastro com sucesso. O novo nome é '{p.nomeP}'");

                        break;

                    case "2":

                        Console.WriteLine("Insira a nova idade para esse cadastro.");
                        p.idade = Console.ReadLine();
                        Console.WriteLine($"Você editou a idade desse cadastro com sucesso. A nova idade é '{p.idade}'");

                        break;

                    case "3":

                        Console.WriteLine("Insira o novo CPF para esse cadastro.");
                        p.cpf = Console.ReadLine();
                        Console.WriteLine($"Você editou o CPF desse cadastro com sucesso. O novo CPF é '{p.cpf}'");

                        break;

                    case "4":

                        Console.WriteLine("Insira o novo e-mail para esse cadastro.");
                        p.email = Console.ReadLine();
                        Console.WriteLine($"Você editou o e-mail desse cadastro com sucesso. O novo e-mail é '{p.email}'");
                    Console.WriteLine();

                        break;

                    default:

                        Console.WriteLine("Você digitou um código inválido.");

                        break;
                }

             
        }


        
    }
}
