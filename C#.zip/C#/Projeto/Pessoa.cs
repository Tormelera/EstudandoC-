﻿namespace Projeto
{
    public class Pessoa
    {
        public string nomeP;
        public string idade;
        public string cpf;
        public string email;

    }
}
