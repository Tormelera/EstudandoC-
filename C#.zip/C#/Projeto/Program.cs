﻿using System;

namespace Projeto
{
    class Program
    {
        static void Main(string[] args)
        {
            GerenciarPessoas gerenciar = new GerenciarPessoas();
            string option;

            do
            {

                Console.WriteLine("1 -; Cadastrar nova pessoa.\n2 -; Listar todos os cadastros existentes.\n3 -; Buscar cadastro pelo nome.\n4 -; Editar cadastro existente.\n0 -; Sair do programa.");
                option = Console.ReadLine();
                Console.WriteLine();

                switch (option)
                {

                    case "1":

                        gerenciar.CadastrarPessoa();

                        break;

                    case "2":

                        gerenciar.ListarPessoa();

                        break;

                    case "3":

                        Pessoa p = new Pessoa();
                        Console.WriteLine("Busque a pessoa pelo nome.");
                        string nome = Console.ReadLine();
                        p = gerenciar.BuscarPessoa(nome);
                        
                        if(p == null)
                        {
                            Console.WriteLine("Não existe nenhum cadastro com esse nome.");
                            Console.WriteLine();
                        }

                        break;

                    case "4":

                        Pessoa pessoa = new Pessoa();

                        Console.WriteLine("Digite o nome da pessoa que deseja editar.");
                        pessoa = gerenciar.BuscarPessoa(Console.ReadLine());
                        Console.WriteLine();

                        if (pessoa != null)
                        {
                            Console.WriteLine("1 -; Editar Nome\n2 -; Editar idade\n3 -; Editar CPF\n4 -; Editar e-mail");
                            string edit = Console.ReadLine();


                            gerenciar.EditarPessoa(pessoa, edit);
                        }
                        else
                            Console.WriteLine("Não existe nenhum cadastro com esse nome.");

                        break;

                    case "0":

                        Console.WriteLine("Você saiu do programa.");

                        break;

                    default:

                        Console.WriteLine("Opção inválida.");

                        break;
                }



            } while (!option.Equals("0"));

            Console.ReadKey();


        }
    }
}
