﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public class GerenciarPessoas
    {
        
        private List<Pessoa> ListaPessoa = new List<Pessoa>();
        
        public void CadastrarPessoa()
        {
            Pessoa p = new Pessoa();

            Console.WriteLine("Digite o nome.");
            p.nomeP = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite a idade.");
            p.idade = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite o CPF.");
            p.cpf = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Digite o e-mail.");
            p.email = Console.ReadLine();
            Console.WriteLine();

            ListaPessoa.Add(p);

        }

        public void ListarPessoa()
        {
            /*  int num = ListaPessoa.Count;

              for (int i = 0; i<num; i++)
              {
                  Pessoa Atual = ListaPessoa[i];
                  Console.WriteLine($"{Atual.nome}, {Atual.idade}, {Atual.cpf}, {Atual.email}.");
              }
            */

            foreach (Pessoa Atual in ListaPessoa)
            {
                Console.WriteLine($"Nome:{Atual.nomeP}\nIdade:{Atual.idade}\nCPF:{Atual.cpf}\nE-mail:{Atual.email}.");
            }

        }

        public void BuscarPessoa(string nome)
        {

            foreach (Pessoa Atual in ListaPessoa)
            {
                if (nome.ToLower().Equals(Atual.nomeP.ToLower()))
                {
                    Console.WriteLine();
                    Console.WriteLine($"Nome:{Atual.nomeP}\nIdade:{Atual.idade}\nCPF:{Atual.cpf}\nE-mail:{Atual.email}.");
                    Console.WriteLine();
                    
                }
            }
        }

        public void EditarPessoa(string name, int num)
        {
            
           
                    switch (num)
                    {
                        case 1:

                            Console.WriteLine("Insira o novo nome para esse cadastro.");
                            Atual.nomeP = Console.ReadLine();
                            Console.WriteLine($"Você editou o nome desse cadastro com sucesso. O novo nome é '{Atual.nomeP}'");

                            break;

                        case 2:

                            Console.WriteLine("Insira a nova idade para esse cadastro.");
                            Atual.idade = Console.ReadLine();
                            Console.WriteLine($"Você editou a idade desse cadastro com sucesso. A nova idade é '{Atual.idade}'");

                            break;

                        case 3:

                            Console.WriteLine("Insira o novo CPF para esse cadastro.");
                            Atual.cpf = Console.ReadLine();
                            Console.WriteLine($"Você editou o CPF desse cadastro com sucesso. O novo CPF é '{Atual.cpf}'");

                            break;

                        case 4:

                            Console.WriteLine("Insira o novo e-mail para esse cadastro.");
                            Atual.email = Console.ReadLine();
                            Console.WriteLine($"Você editou o e-mail desse cadastro com sucesso. O novo e-mail é '{Atual.email}'");

                            break;

                        default:

                            Console.WriteLine("Você digitou um código inválido.");

                            break;
                    }
                
            
        }

        
    }
}
