﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    class Program
    {
        static void Main(string[] args)
        {
            GerenciarPessoas gerenciar = new GerenciarPessoas();

            while (true)
            {
                

                int code;

                Console.WriteLine("1 -; Cadastro.\n2 -; Listar.\n3 -; Buscar.\n4 -; Editar.");
                code = int.Parse(Console.ReadLine());

                switch (code)
                {
                    
                    case 1:

                        gerenciar.CadastrarPessoa();

                        break;

                    case 2:

                        gerenciar.ListarPessoa();

                        break;

                    case 3:

                        Console.WriteLine("Busque a pessoa pelo nome.");
                        string nome = Console.ReadLine();
                        gerenciar.BuscarPessoa(nome);

                        break;

                    case 4:

                        Console.WriteLine("Digite o nome da pessoa que deseja editar.");
                        nome = Console.ReadLine();
                        gerenciar.BuscarPessoa(nome);
                        Console.WriteLine();
                        Console.WriteLine("1 -; Editar Nome\n2 -; Editar idade\n3 -; Editar CPF\n4 -; Editar e-mail");
                        code = int.Parse(Console.ReadLine());
                        gerenciar.EditarPessoa(code);
                      

                        break;


                    default:

                        Console.WriteLine("Opção inválida.");

                        break;
                }

                

            }

            Console.ReadKey();


        }
    }
}
