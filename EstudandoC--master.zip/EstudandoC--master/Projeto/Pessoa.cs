﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public class Pessoa
    {
        public string nomeP;
        public string idade;
        public string cpf;
        public string email;

    }
}
